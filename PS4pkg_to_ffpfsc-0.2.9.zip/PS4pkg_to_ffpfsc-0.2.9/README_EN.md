# PS4 FFPFSC

The English README is now the project landing page: [README.md](README.md).

The Russian version is available in [README_RU.md](README_RU.md).


package com.example.pkgconverter;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import com.chaquo.python.*;

public class MainActivity extends Activity {
    TextView status, log; Button convert; Spinner format; Uri selected;
    Python py;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        py=Python.getInstance();
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28,28,28,28);
        TextView title=new TextView(this); title.setText("PKG Converter"); title.setTextSize(30);
        TextView sub=new TextView(this); sub.setText("PS4 converter • supported packages only"); sub.setTextSize(16);
        Button pick=new Button(this); pick.setText("SELECT .PKG");
        format=new Spinner(this);
        format.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,
            new String[]{".exfat image",".ffpfsc image"}));
        convert=new Button(this); convert.setText("CONVERT"); convert.setEnabled(false);
        status=new TextView(this); status.setText("Select a package.");
        log=new TextView(this); log.setTextSize(13);
        root.addView(title); root.addView(sub); root.addView(pick);
        root.addView(format); root.addView(convert); root.addView(status); root.addView(log);
        setContentView(root);
        pick.setOnClickListener(v->pick());
        convert.setOnClickListener(v->runConvert());
    }
    void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/octet-stream");
        i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,7);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d); if(r!=7||c!=RESULT_OK||d==null)return;
        selected=d.getData(); try { getContentResolver().takePersistableUriPermission(selected,
            Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored){}
        status.setText("Checking package…"); convert.setEnabled(false);
        new Thread(()->{
            try{
                File f=copyToCache(selected);
                PyObject res=py.getModule("bridge.converter").callAttr("inspect_pkg",f.getAbsolutePath());
                runOnUiThread(()->{ log.setText(res.toString()); status.setText("Ready"); convert.setEnabled(true);});
            }catch(Exception e){runOnUiThread(()->log.setText("Error: "+e));}
        }).start();
    }
    void runConvert(){
        convert.setEnabled(false); status.setText("Converting…");
        new Thread(()->{
            try{
                File f=copyToCache(selected);
                File out=new File(getExternalFilesDir(null),"converted"); out.mkdirs();
                String fmt=format.getSelectedItemPosition()==0?"exfat":"ffpfsc";
                PyObject res=py.getModule("bridge.converter").callAttr("convert_ps4",f.getAbsolutePath(),out.getAbsolutePath(),fmt);
                runOnUiThread(()->{log.setText(res.toString());status.setText("Finished");convert.setEnabled(true);});
            }catch(Exception e){runOnUiThread(()->{log.setText("Error: "+e);status.setText("Failed");convert.setEnabled(true);});}
        }).start();
    }
    File copyToCache(Uri u)throws Exception{
        String name=queryName(u); if(name==null)name="input.pkg";
        File f=new File(getCacheDir(),name);
        try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(f)){
            byte[] buf=new byte[1024*1024]; int n; while((n=in.read(buf))>0)out.write(buf,0,n);
        } return f;
    }
    String queryName(Uri u){
        Cursor c=getContentResolver().query(u,null,null,null,null);
        if(c!=null)try{int x=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(x>=0&&c.moveToFirst())return c.getString(x);}finally{c.close();}
        return null;
    }
}

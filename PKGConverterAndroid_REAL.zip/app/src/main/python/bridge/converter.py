
import os, sys, json, shutil, subprocess, time
from pathlib import Path

def _resource_root():
    # The workflow copies the PS4 source tree beside this bridge.
    return Path(__file__).resolve().parents[1] / "backend"

def _prepare():
    root = _resource_root()
    root.mkdir(parents=True, exist_ok=True)
    bin_dir = root / "bin"
    bin_dir.mkdir(exist_ok=True)
    helper = bin_dir / "ps4_pkg_extract"
    if helper.exists():
        try: helper.chmod(0o755)
        except OSError: pass
    os.environ["PS4FFPSC_RESOURCE_ROOT"] = str(root)
    data = Path(os.environ.get("HOME", str(Path.home()))) / "ps4ffpsc"
    data.mkdir(parents=True, exist_ok=True)
    os.environ["PS4FFPSC_DATA_ROOT"] = str(data)
    return root

def inspect_pkg(pkg):
    _prepare()
    from ps4ffpsc.inventory import inspect_package, find_extractor
    from pathlib import Path
    p=Path(pkg)
    helper=find_extractor(_resource_root())
    if helper is None:
        return {"ok":False,"error":"PS4 engine is not installed in this build."}
    result=inspect_package(helper,p)
    return {"ok":bool(result.get("supported")),"result":result}

def convert_ps4(pkg, output_dir, fmt):
    root=_prepare()
    pkg=Path(pkg).resolve()
    out=Path(output_dir).resolve()
    data=Path(os.environ["PS4FFPSC_DATA_ROOT"])
    work=data/"work"
    out.mkdir(parents=True, exist_ok=True)
    cmd=[sys.executable,"-m","ps4ffpsc","build",
         "--pkg-file",str(pkg),"--output-dir",str(out),
         "--work-dir",str(work),"--temp-dir",str(data/"tmp"),
         "--output-format",fmt,"--json","--force"]
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                     text=True,encoding="utf-8",errors="replace")
    return {"ok":p.returncode==0,"output":p.stdout,"code":p.returncode}

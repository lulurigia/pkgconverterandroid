# PKG Converter Android — real backend build
This project embeds Python using Chaquopy and is prepared for the PS4 FFPFSC backend.
The GitHub Actions workflow fetches the upstream PS4 source, builds its native extractor
for arm64-v8a, and copies the Python conversion pipeline and MkPFS into the app.
Encrypted/unsupported retail packages are rejected; no keys or DRM are bypassed.

# PKG Converter for Android

This is an Android Studio starter project for a unified PS4/PS5 PKG front-end.

## What is already implemented

- Android file picker for `.pkg`
- Package header inspection
- Heuristic PS4/PS5 detection using identifiers commonly exposed in package data
- Output target selector:
  - folder/dump
  - exFAT
  - FFPFSC
  - FFPKG
- A clean place to plug in native conversion engines later

## Important limitation

This project is intentionally a **front-end/inspection build**, not a finished PKG conversion engine.

PS4 FFPFSC and PS5 PKG tooling currently rely on platform-specific implementations. The current PS4 FFPFSC project provides Windows x64 and macOS ARM64 releases, while the current PS5 PKG Tool is a Windows application.

The Android project therefore does NOT pretend that a simple Android APK can magically decode every PS4/PS5 PKG.

Retail/encrypted packages may require matching cryptographic material. This project does not obtain keys, bypass DRM, or circumvent package protections.

## Build in Android Studio

1. Install Android Studio (latest stable).
2. Extract this ZIP.
3. Open the extracted `PKGConverterAndroid` directory in Android Studio.
4. Allow Gradle to download the Android Gradle Plugin and Kotlin dependencies.
5. Install Android SDK Platform 35 when Android Studio asks.
6. Make sure Android Studio is using JDK 17:
   - Settings
   - Build, Execution, Deployment
   - Build Tools
   - Gradle
   - Gradle JDK = Embedded JDK 17
7. Let Gradle Sync finish.
8. Connect your Android phone with USB debugging enabled, or create an emulator.
9. Press Run ▶.
10. To create an APK:
    Build → Build Bundle(s) / APK(s) → Build APK(s)
11. Android Studio will show a link to the generated APK.

## What the next engineering step is

To make this a *real* converter rather than an inspector, add ARM64 Android builds of the actual package/image engines:

### PS4 side
The open-source PS4 FFPFSC project provides:
- PS4 PKG input
- unpacked PS4 game input
- FFPFSC output
- raw exFAT output
- validation and progress handling

### PS5 side
The open-source PS5 PKG Tool provides:
- PS5 package reading/extraction for supported debug/community packages
- dump ↔ exFAT
- dump ↔ FFPKG
- dump ↔ FFPFSC
- debug-package conversion

The Android app should call those engines through JNI/NDK or a native ARM64 library rather than attempting to reimplement the complete package filesystem in the UI layer.

## Recommended production architecture

Android UI
   ↓
PackageDetector
   ↓
PS4Backend / PS5Backend
   ↓
Native ARM64 package engine
   ↓
Folder / exFAT / FFPKG / FFPFSC

The detector should be replaced with authoritative parser results once the native engines are integrated.

## Safety / data handling

- The selected source PKG is read-only.
- The app should never overwrite the source.
- Conversion should write to a user-selected output directory.
- Failed conversions should retain diagnostic logs.
- No external game downloading or key retrieval is included.

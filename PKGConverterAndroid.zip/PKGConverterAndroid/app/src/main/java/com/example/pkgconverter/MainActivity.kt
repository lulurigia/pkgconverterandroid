package com.example.pkgconverter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.BufferedInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var details: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "PKG Converter"
            textSize = 28f
            setPadding(0, 0, 0, 18)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Automatic PS4 / PS5 package inspection"
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        root.addView(subtitle)

        val pick = Button(this).apply {
            text = "Select .PKG"
            setOnClickListener { pickPkg() }
        }
        root.addView(pick, match())

        status = TextView(this).apply {
            text = "No package selected."
            textSize = 17f
            setPadding(0, 28, 0, 12)
        }
        root.addView(status)

        details = TextView(this).apply {
            text = "The app will inspect the package header and look for platform/content identifiers.\n\n"
            textSize = 15f
        }
        root.addView(details)

        val outputLabel = TextView(this).apply {
            text = "Output target"
            textSize = 18f
            setPadding(0, 24, 0, 8)
        }
        root.addView(outputLabel)

        val output = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("Folder / dump", ".exfat image", ".ffpfsc image", ".ffpkg image")
            )
        }
        root.addView(output, match())

        val note = TextView(this).apply {
            text = "\nConversion engine status: inspection/front-end only.\n\n" +
                   "A real PKG → image conversion engine must be ported/bundled separately. " +
                   "This project deliberately does not bypass encrypted retail packages or obtain keys."
            textSize = 14f
        }
        root.addView(note)

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun match(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

    private fun pickPkg() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Activity result API kept simple for this sample project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        selectedUri = uri
        inspect(uri)
    }

    private fun inspect(uri: Uri) {
        val name = queryName(uri) ?: uri.toString().substringAfterLast('/')
        status.text = "Selected: $name"
        try {
            contentResolver.openInputStream(uri)?.use { raw ->
                val input = BufferedInputStream(raw)
                val head = ByteArray(1024 * 1024)
                val n = input.read(head)
                val result = PkgInspector.inspect(head, n, name)
                details.text = result
            }
        } catch (e: Exception) {
            details.text = "Could not inspect package:\n${e.message}"
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
        }
        return null
    }
}

object PkgInspector {
    fun inspect(bytes: ByteArray, length: Int, filename: String): String {
        if (length < 4) return "File is too small to be a valid package."

        val magic = String(bytes.copyOfRange(0, 4), Charsets.ISO_8859_1)
        val hex = bytes.copyOfRange(0, 4).joinToString(" ") { "%02X".format(it) }

        val text = String(bytes.copyOf(length), Charsets.ISO_8859_1)
        val ids = Regex("""(?:PPSA|CUSA|PCAS|UP[0-9A-Z]{4})[-_A-Z0-9]{0,20}""")
            .findAll(text)
            .map { it.value }
            .distinct()
            .take(10)
            .toList()

        val ps5 = ids.any { it.startsWith("PPSA") || it.startsWith("PPS") }
        val ps4 = ids.any { it.startsWith("CUSA") || it.startsWith("PCAS") || it.startsWith("UP") }

        val platform = when {
            ps5 && !ps4 -> "Likely PS5"
            ps4 && !ps5 -> "Likely PS4"
            ps4 && ps5 -> "Ambiguous PS4/PS5 indicators"
            else -> "Unknown platform (metadata not exposed in the first 1 MiB)"
        }

        return buildString {
            appendLine("Package inspection")
            appendLine("------------------")
            appendLine("File: $filename")
            appendLine("First 4 bytes: $hex ($magic)")
            appendLine("Platform: $platform")
            if (ids.isNotEmpty()) {
                appendLine("Identifiers found:")
                ids.forEach { appendLine("  • $it") }
            } else {
                appendLine("No recognizable CUSA/PPSA-style identifier found in the sampled header.")
            }
            appendLine()
            appendLine("Important: this is a heuristic detector, not a cryptographic package validator.")
            appendLine("A production converter should use the actual PS4/PS5 PKG parsers before conversion.")
        }
    }
}
